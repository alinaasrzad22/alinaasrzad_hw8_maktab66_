function calculate() {
    var radius=prompt("Please enter the size of the radius","");
    var pi=3.14;  
    var circ=2*pi*radius;
    var d=alert(`The circumference of a circle with radius ` +  `${radius}` +  "is "   +  `${circ}` + `.`)
    }